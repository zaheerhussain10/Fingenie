import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import API from "../services/api";
import { depositMoney, withdrawMoney } from "../services/transactionService";
import CreditScoreCard from "../components/CreditScoreCard";


const Dashboard = () => {

  const [accounts, setAccounts] = useState([]);
  const [amount, setAmount] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();
  const [showModal, setShowModal] = useState(false);
const [selectedAccount, setSelectedAccount] = useState(null);
const [actionType, setActionType] = useState(""); // deposit/withdraw
const [showTransferModal, setShowTransferModal] = useState(false);
const [fromAccount, setFromAccount] = useState(null);
const [toAccount, setToAccount] = useState("");

  useEffect(() => {
    fetchAccounts();
  }, []);

  const fetchAccounts = async () => {
  try {
    const res = await API.get("/accounts/my"); 
    setAccounts(res.data);
  } catch (error) {
    console.error(error);
  }
};
const handleWithdraw = async (accountId) => {
  const amount = prompt("Enter amount to withdraw");

  if (!amount) return;

  try {
    await API.post("/transactions/withdraw", {
      accountId,
      amount: Number(amount)
    });

    setMessage("Withdraw successful ");

    fetchAccounts();

    setTimeout(() => setMessage(""), 3000);
  } catch (error) {
    setMessage("Withdraw failed ");
  }
};
const handleDeposit = async (accountId) => {
  const amount = prompt("Enter amount to deposit");

  if (!amount) return;

  try {
    await API.post("/transactions/deposit", {
      accountId,
      amount: Number(amount)
    });

    setMessage("Deposit successful "); 

    fetchAccounts();

    setTimeout(() => setMessage(""), 3000); 
  } catch (error) {
    setMessage("Deposit failed "); 
  }
};
const openModal = (accountId, type) => {
  setSelectedAccount(accountId);
  setActionType(type);
  setShowModal(true);
};
const handleSubmit = async () => {
  try {

    if (actionType === "deposit") {
      await depositMoney({
        accountId: selectedAccount,
        amount: Number(amount)
      });
    }

    if (actionType === "withdraw") {
      await withdrawMoney({
        accountId: selectedAccount,
        amount: Number(amount)
      });
    }

    fetchAccounts();
    setMessage(`${actionType} successful`);

  } catch (error) {
    console.error(error);
    setMessage(`${actionType} failed `);
  }

  setShowModal(false);
  setAmount("");
};
const [transactions, setTransactions] = useState([]);
const [showTransactions, setShowTransactions] = useState(false);

const viewTransactions = async (accountId) => {
  try {
    const res = await API.get(`/transactions/account/${accountId}`);
    setTransactions(res.data);
    setShowTransactions(true);
  } catch (error) {
    console.error(error);
  }
};


const openTransferModal = (accountId) => {
  setFromAccount(accountId);
  setShowTransferModal(true);
};
const handleTransfer = async () => {
  try {

    await API.post("/transactions/transfer", {
      fromAccountId: fromAccount,
      toAccountId: Number(toAccount),
      amount: Number(amount)
    });

    setMessage("Transfer successful ✅");
    fetchAccounts();

  } catch (error) {
    console.error(error);
    setMessage(error.response?.data || "Transfer failed ❌");
  }

  setShowTransferModal(false);
  setAmount("");
  setToAccount("");
};




  return (
    
    <div style={{ background: "#f5f7fa", minHeight: "100vh", padding: "20px" }}>
        {message && (
  <div style={toast}>
    {message}
  </div>
)}


      {/* HEADER */}
      <div style={{ display: "flex", justifyContent: "space-between" }}>

        <h2>Dashboard </h2>
        <div style={loanContainer}>

  <div style={loanCard} onClick={() => navigate("/portfolio")}>
    <h4>Investment Portfolio</h4>
  </div>

</div>
<div style={loanCard} onClick={() => navigate("/investment")}>
  <h4>Investments</h4>
</div>


        {/* ✅ CREATE ACCOUNT BUTTON */}
        <button onClick={() => navigate("/create-account")} style={button}>
          + Create Account
        </button>
      </div>

      <h3>Your Accounts</h3>

      {/* ✅ ACCOUNTS LIST */}
{accounts.map((acc) => (
  <div key={acc.id} style={card}>
    
    <h4>{acc.accountType} Account</h4>
    <p><b>Account No:</b> {acc.accountNumber}</p>
    <p><b>Balance:</b> ₹ {acc.balance}</p>

    <div style={{ display: "flex", gap: "10px" }}>
      <button onClick={() => openModal(acc.id, "deposit")}>Deposit</button>
      <button onClick={() => openModal(acc.id, "withdraw")}>Withdraw</button>
      
      {/* ✅ FIXED */}
      <button onClick={() => viewTransactions(acc.id)}>
        View Transactions
      </button>
      <button onClick={() => openTransferModal(acc.id)}>
  Transfer
</button>
    </div>

  </div>
))}

{showModal && (
  <div style={overlay}>
    <div style={modal}>
      <h3>{actionType === "deposit" ? "Deposit Money" : "Withdraw Money"}</h3>

      <input
        type="number"
        placeholder="Enter amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        style={input}
      />

      <div style={{ marginTop: "15px" }}>
        <button onClick={handleSubmit} style={button}>Submit</button>
        <button onClick={() => setShowModal(false)} style={cancelBtn}>Cancel</button>
      </div>
    </div>
  </div>
)}

{showTransactions && (
  <div style={modalOverlay}>
    <div style={modalBox}>
      <h3>Transaction History</h3>

      {transactions.length === 0 ? (
        <p>No transactions found</p>
      ) : (
        <table style={table}>
          <thead>
            <tr>
              <th>Amount</th>
              <th>Type</th>
              <th>Status</th>
              <th>Time</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((tx) => (
              <tr key={tx.id}>
                <td>₹ {tx.amount}</td>
                <td>{tx.type}</td>
                <td>{tx.status}</td>
                <td>{tx.timestamp}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <button onClick={() => setShowTransactions(false)}>
        Close
      </button>
    </div>
    
  </div>
)}
{showTransferModal && (
  <div style={overlay}>
    <div style={modal}>
      <h3>Transfer Money</h3>

      <input
        type="number"
        placeholder="To Account ID"
        value={toAccount}
        onChange={(e) => setToAccount(e.target.value)}
        style={input}
      />

      <input
        type="number"
        placeholder="Enter amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        style={input}
      />

      <div style={{ marginTop: "15px" }}>
        <button onClick={handleTransfer}>Transfer</button>
        <button onClick={() => setShowTransferModal(false)}>
          Cancel
        </button>
      </div>
    </div>
  </div>
)}
<div style={cardContainer}>

  {/* ✅ Credit Score */}
  <CreditScoreCard />

  {/* ✅ Total Balance */}
  <div style={card}>
    <h3>Total Balance</h3>
    <p>
      ₹ {accounts.reduce((sum, acc) => sum + acc.balance, 0)}
    </p>
  </div>



  <div style={loanCard} onClick={() => navigate("/loan")}>
  
    <h4>loans</h4>
    <p>Click Here</p>
  </div>

</div>



    </div>
    
  );
};

// ✅ styles
const card = {
  background: "white",
  padding: "15px",
  marginTop: "10px",
  borderRadius: "10px",
  boxShadow: "0 4px 10px rgba(0,0,0,0.1)"
};
const loanContainer = {
  display: "grid",
  gridTemplateColumns: "repeat(4, 1fr)",
  gap: "15px",
  marginTop: "20px"
};

const loanCard = {
  background: "white",
  padding: "15px",
  borderRadius: "10px",
  textAlign: "center",
  cursor: "pointer",
  boxShadow: "0 4px 10px rgba(0,0,0,0.1)"
};
const cardContainer = {
  display: "grid",
  gridTemplateColumns: "repeat(3, 1fr)", 
  gap: "20px",
  marginBottom: "20px",
  alignItems: "stretch"
};

const button = {
  padding: "10px 15px",
  background: "#007bff",
  color: "white",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer"
};
const toast = {
  position: "fixed",
  top: "20px",
  right: "20px",
  background: "#333",
  color: "white",
  padding: "12px 20px",
  borderRadius: "8px",
  boxShadow: "0 4px 10px rgba(0,0,0,0.2)",
  zIndex: 1000
};
const overlay = {
  position: "fixed",
  top: 0,
  left: 0,
  width: "100%",
  height: "100%",
  background: "rgba(0,0,0,0.5)",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  zIndex: 1000
};

const modal = {
  background: "white",
  padding: "25px",
  borderRadius: "12px",
  width: "300px",
  boxShadow: "0 4px 15px rgba(0,0,0,0.3)"
};

const input = {
  width: "100%",
  padding: "10px",
  marginTop: "10px",
  borderRadius: "8px",
  border: "1px solid #ccc"
};

const cancelBtn = {
  marginLeft: "10px",
  background: "gray",
  color: "white",
  padding: "8px 12px",
  border: "none",
  borderRadius: "8px"
};
const table = {
  width: "100%",
  marginTop: "10px",
  borderCollapse: "collapse"
};

const modalOverlay = {
  position: "fixed",
  top: 0,
  left: 0,
  width: "100%",
  height: "100%",
  background: "rgba(0,0,0,0.5)",
  display: "flex",
  justifyContent: "center",
  alignItems: "center"
};

const modalBox = {
  background: "white",
  padding: "20px",
  borderRadius: "10px",
  width: "500px"
};
export default Dashboard;