
import { useState } from "react";
import { getPortfolio } from "../services/portfolioService";

const PortfolioPage = () => {

  const [accountId, setAccountId] = useState("");
  const [portfolio, setPortfolio] = useState(null);
  const [message, setMessage] = useState("");

  const handleLoad = async () => {
  try {
    const res = await getPortfolio(accountId);

    console.log("API RESPONSE:", res);
    console.log("DATA:", res.data); 

    setPortfolio(res.data);
    setMessage("");

  } catch (error) {
    console.error("ERROR:", error);

    if (error.response) {
      console.error("BACKEND ERROR:", error.response.data);

      setMessage(
        error.response.data?.message || "Error loading portfolio "
      );
    } else {
      setMessage("Server not reachable ");
    }

    setPortfolio(null);
  }
};

  return (
    <div style={container}>

      <h2>Investment Portfolio</h2>

      <input
        placeholder="Enter Account ID"
        value={accountId}
        onChange={(e) => setAccountId(e.target.value)}
        style={input}
      />

      <button onClick={handleLoad} style={button}>
        Load Portfolio
      </button>

      {message && <p>{message}</p>}

      {/* ✅ PORTFOLIO DETAILS */}
      {portfolio && (
        <div style={card}>

          <h3>Portfolio Summary</h3>

          <p><b>Total Investment:</b> ₹ {portfolio.totalInvestment}</p>
          <p><b>Total Returns:</b> ₹ {portfolio.totalReturns}</p>
          <p><b>No. of Investments:</b> {portfolio.numberOfInvestments}</p>
          <p><b>Current Balance:</b> ₹ {portfolio.currentBalance}</p>

        </div>
      )}

    </div>
  );
};
const container = {
  maxWidth: "400px",
  margin: "40px auto",
  display: "flex",
  flexDirection: "column",
  gap: "10px"
};

const input = {
  padding: "10px",
  borderRadius: "8px",
  border: "1px solid #ccc"
};

const button = {
  padding: "10px",
  background: "#10b981",
  color: "white",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer"
};

const card = {
  background: "white",
  padding: "15px",
  marginTop: "15px",
  borderRadius: "10px",
  boxShadow: "0 4px 10px rgba(0,0,0,0.1)"
};

export default PortfolioPage;
