import React, { useState } from "react";
import { createAccount } from "../services/accountService";

const CreateAccount = () => {

  const [formData, setFormData] = useState({
    balance: "",
    accountType: "SAVINGS"
  });

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async () => {
    try {
      await createAccount({
        balance: Number(formData.balance),
        accountType: formData.accountType
      });

      alert("Account Created ");

    } catch (error) {
      console.error(error);
      alert("Failed to create account ");
    }
  };

  return (
    <div style={container}>
      <div style={card}>
        <h3>Create Bank Account</h3>

        <input
          name="balance"
          placeholder="Initial Balance"
          style={input}
          value={formData.balance}
          onChange={handleChange}
        />

        <select
          name="accountType"
          style={input}
          value={formData.accountType}
          onChange={handleChange}
        >
          <option value="SAVINGS">Savings</option>
          <option value="CURRENT">Current</option>
        </select>

        <button style={button} onClick={handleSubmit}>
          Create Account
        </button>
      </div>
    </div>
  );
};

const container = {
  height: "100vh",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  background: "#f5f7fa"
};

const card = {
  background: "white",
  padding: "30px",
  borderRadius: "15px",
  boxShadow: "0 4px 15px rgba(0,0,0,0.1)"
};

const input = {
  display: "block",
  width: "100%",
  padding: "10px",
  marginTop: "10px",
  borderRadius: "8px",
  border: "1px solid #ccc"
};

const button = {
  marginTop: "15px",
  padding: "10px",
  width: "100%",
  background: "#007bff",
  color: "white",
  border: "none",
  borderRadius: "8px"
};

export default CreateAccount;