import { useState } from "react";
import { applyLoan } from "../services/loanService";
import LoanList from "../components/LoanList";

const LoanPage = () => {

  const [accountId, setAccountId] = useState("");
  const [amount, setAmount] = useState("");
  const [tenure, setTenure] = useState("");
  const [loanType, setLoanType] = useState("");
  const [message, setMessage] = useState("");

  const handleApply = async () => {
    try {

      await applyLoan({
        accountId: Number(accountId),
        amount: Number(amount),
        tenure: Number(tenure),
        loanType
      });

      setMessage("Loan Applied ✅");

    } catch (error) {
      setMessage("Loan Failed ❌");
    }
  };

  return (
    <div style={container}>

      <h2>Apply Loan</h2>

      <input
        placeholder="Account ID"
        value={accountId}
        onChange={(e) => setAccountId(e.target.value)}
        style={input}
      />

      <input
        placeholder="Amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        style={input}
      />

      <input
        placeholder="Tenure (months)"
        value={tenure}
        onChange={(e) => setTenure(e.target.value)}
        style={input}
      />

      <select
        value={loanType}
        onChange={(e) => setLoanType(e.target.value)}
        style={input}
      >
        <option value="">Select Loan</option>
        <option value="CAR">Car Loan</option>
        <option value="HOME">Home Loan</option>
        <option value="PERSONAL">Personal Loan</option>
        <option value="EDUCATION">Education Loan</option>
      </select>

      <button onClick={handleApply} style={button}>
        Apply Loan
      </button>

      {message && <p>{message}</p>}

      {/* ✅ important */}
      <LoanList />

    </div>
  );
};

export default LoanPage;

const container = {
  maxWidth: "400px",
  margin: "40px auto",
  display: "flex",
  flexDirection: "column",
  gap: "10px"
};

const input = {
  padding: "10px",
  borderRadius: "8px",
  border: "1px solid #ccc"
};

const button = {
  padding: "10px",
  background: "#2563eb",
  color: "white",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer"
};