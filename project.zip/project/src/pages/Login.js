import React, { useState } from "react";
import API from "../services/api";
import { useNavigate } from "react-router-dom";
import AuthLayout from "../components/AuthLayout";

const Login = () => {

  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
  try {
    const response = await API.post("/users/login", {
      email,
      password
    });

    localStorage.setItem("token", response.data);

    alert("Login Success ");
    navigate("/dashboard");

  } catch (error) {
    alert("Login Failed ");
  }
};

 return (
  <AuthLayout>

    <h2 style={{ textAlign: "center" }}>FinGenie</h2>
    <p style={{ textAlign: "center", color: "#888" }}>Welcome back</p>

    <input
  style={inputStyle}
  placeholder="Email"
  value={email}
  onChange={(e) => setEmail(e.target.value)}
/>

<input
  style={inputStyle}
  type="password"
  placeholder="Password"
  value={password}
  onChange={(e) => setPassword(e.target.value)}
/>

    <button style={buttonStyle} onClick={handleLogin}>
      Login
    </button>

    <p style={{ textAlign: "center", marginTop: "20px" }}>
      Don’t have an account?{" "}
      <span onClick={() => navigate("/register")} style={{ color: "#007bff", cursor: "pointer" }}>
        Create Account
      </span>
    </p>

  </AuthLayout>
  );
};

// ✅ styles
const inputStyle = {
  width: "100%",
  padding: "12px",
  marginTop: "15px",
  borderRadius: "10px",
  border: "1px solid #ddd",
  outline: "none",
  fontSize: "14px"
};

const buttonStyle = {
  width: "100%",
  marginTop: "20px",
  padding: "12px",
  borderRadius: "10px",
  border: "none",
  backgroundColor: "#007bff",
  color: "white",
  fontWeight: "bold",
  cursor: "pointer"
};

export default Login;