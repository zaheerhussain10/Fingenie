package com.wipro.FinGenieAI.service;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.FinGenieAI.dto.LoanDTO;
import com.wipro.FinGenieAI.entity.Account;
import com.wipro.FinGenieAI.entity.Loan;
import com.wipro.FinGenieAI.enums.LoanStatus;
import com.wipro.FinGenieAI.exception.ResourceNotFoundException;
import com.wipro.FinGenieAI.mapper.LoanMapper;
import com.wipro.FinGenieAI.repository.AccountRepository;
import com.wipro.FinGenieAI.repository.LoanRepository;

@Service
public class LoanServiceImpl implements LoanService {

    private static final Logger logger =
            LoggerFactory.getLogger(LoanServiceImpl.class);

    @Autowired
    private LoanRepository loanRepository;

    @Autowired
    private AccountRepository accountRepository;

    // ✅ APPLY LOAN
    @Override
    public LoanDTO applyLoan(LoanDTO dto) {

        logger.info("Loan request received for accountId: {}", dto.getAccountId());

        // ✅ 1. Validate account
        Account account = accountRepository.findById(dto.getAccountId())
                .orElseThrow(() -> {
                    logger.error("Account not found: {}", dto.getAccountId());
                    return new ResourceNotFoundException("Account not found");
                });

        // ✅ 2. Map DTO → Entity
        Loan loan = LoanMapper.toEntity(dto);
        loan.setAccount(account);
        loan.setAppliedDate(LocalDateTime.now());

        // ✅ 3. ELIGIBILITY CHECK 🔥
        // Rule: user must have at least 20% of loan amount as balance
        if (account.getBalance() >= (dto.getAmount() * 0.2)) {

            loan.setStatus(LoanStatus.APPROVED);
            loan.setApprovedDate(LocalDateTime.now());

            logger.info("Loan approved for accountId: {}, amount: {}", 
                        dto.getAccountId(), dto.getAmount());

        } else {

            loan.setStatus(LoanStatus.REJECTED);

            logger.warn("Loan rejected due to insufficient balance. accountId: {}", 
                        dto.getAccountId());
        }

        // ✅ 4. Save loan
        Loan saved = loanRepository.save(loan);

        logger.info("Loan saved successfully with id: {}", saved.getId());

        return LoanMapper.toDTO(saved);
    }

    // ✅ GET LOAN BY ID
    @Override
    public LoanDTO getLoanById(Long id) {

        logger.info("Fetching loan with id: {}", id);

        Loan loan = loanRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("Loan not found with id: {}", id);
                    return new ResourceNotFoundException("Loan not found");
                });

        return LoanMapper.toDTO(loan);
    }
}